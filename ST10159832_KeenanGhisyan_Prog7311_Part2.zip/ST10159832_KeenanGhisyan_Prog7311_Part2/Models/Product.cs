﻿using System;
using System.Collections.Generic;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

public partial class Product  //https://www.youtube.com/watch?v=7S_tz1z_5bA
{
    public int ProductId { get; set; }

    public int FarmerId { get; set; }

    public string ProductName { get; set; } = null!;

    public string? Category { get; set; } = null!;

    public DateOnly? ProductDate { get; set; }

    public virtual Farmer? Farmer { get; set; }
}
