﻿using System;
using System.Collections.Generic;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

public partial class User  //https://www.youtube.com/watch?v=7S_tz1z_5bA
{
    public int UserId { get; set; }

    public string FullName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Role { get; set; } = null!;
}
