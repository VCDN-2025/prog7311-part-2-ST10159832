﻿using System;
using System.Collections.Generic;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Models;   //https://www.youtube.com/watch?v=7S_tz1z_5bA

public partial class Farmer
{
    public int FarmerId { get; set; }

    public string Email { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? ContactNumber { get; set; }

    public string? Address { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
