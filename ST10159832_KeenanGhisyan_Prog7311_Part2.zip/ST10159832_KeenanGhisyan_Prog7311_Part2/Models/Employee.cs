﻿using System;
using System.Collections.Generic;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Models;  //https://www.youtube.com/watch?v=7S_tz1z_5bA

public partial class Employee
{
    public int EmployeeId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? ContactNumber { get; set; }
}
