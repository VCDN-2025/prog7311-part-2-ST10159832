﻿using Microsoft.AspNetCore.Mvc;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers
{
    public class LoginController : Controller  //https://www.youtube.com/watch?v=E7Voso411Vs
    {
        private readonly FarmManagementContext _context;

        public LoginController(FarmManagementContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(User user)
        {
            var validUser = _context.Users
                .FirstOrDefault(u => u.Email == user.Email && u.Password == user.Password);

            if (validUser != null)
            {
                HttpContext.Session.SetString("UserRole", validUser.Role);
                HttpContext.Session.SetString("LoggedInUser", validUser.Email);
                HttpContext.Session.SetString("LoggedInUserName", validUser.FullName); 
                HttpContext.Session.SetInt32("UserId", validUser.UserId);

                return validUser.Role.Equals("Farmer", StringComparison.OrdinalIgnoreCase)
                    ? RedirectToAction("Farmer", "Dashboard")
                    : RedirectToAction("Employee", "Dashboard");
            }

            ViewBag.ErrorMessage = "Invalid login credentials.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}

