﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers
{
    public class EmployeesController : Controller  //https://www.youtube.com/watch?v=E7Voso411Vs
    {
        private readonly FarmManagementContext _context;

        public EmployeesController(FarmManagementContext context)
        {
            _context = context;
        }

        // GET: Employees
        public IActionResult Index()
        {
            // Optional: Redirect unauthorized users
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Employee")
                return RedirectToAction("Index", "Login");

            return View();
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(int? id) //https://www.youtube.com/watch?v=_tiOquA9Yz4
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Employee")
                return RedirectToAction("Index", "Login");

            if (id == null)
                return NotFound();

            var farmer = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Farmer");

            if (farmer == null)
                return NotFound();

            return View(farmer);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "Employee")
                return RedirectToAction("Index", "Login");

            var farmer = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Farmer");

            if (farmer != null)
            {
                _context.Users.Remove(farmer);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction("Index", "Users");
        }
    }
}
