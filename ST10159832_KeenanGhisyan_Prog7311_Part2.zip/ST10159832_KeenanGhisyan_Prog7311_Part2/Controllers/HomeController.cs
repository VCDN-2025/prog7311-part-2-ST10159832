using Microsoft.AspNetCore.Mvc;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;
using System.Diagnostics;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers //https://www.youtube.com/watch?v=E7Voso411Vs
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
