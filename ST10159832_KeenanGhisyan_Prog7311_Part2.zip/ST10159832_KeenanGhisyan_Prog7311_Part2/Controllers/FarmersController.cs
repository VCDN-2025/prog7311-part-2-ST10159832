﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers
{
    public class FarmersController : Controller   //https://www.youtube.com/watch?v=E7Voso411Vs
    {
        private readonly FarmManagementContext _context;

        public FarmersController(FarmManagementContext context)
        {
            _context = context;
        }

        // Show all products to any logged-in farmer
        public async Task<IActionResult> Index(string searchCategory, string searchName) //https://www.youtube.com/watch?v=REG-p_eFNIw
        {
            // Optional: Ensure user is logged in
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
                return RedirectToAction("Login", "Users");

            var LoggedUser = HttpContext.Session.GetString("LoggedInUser");

            var farmerId = _context.Farmers.Where(f => f.Email == LoggedUser).Select(f => f.FarmerId).FirstOrDefault();

            var products = _context.Products.Where(p => p.FarmerId == farmerId);

            //var products = _context.Products.Include(p => p.Farmer).AsQueryable();

            if (!string.IsNullOrEmpty(searchCategory))
                products = products.Where(p => p.Category.Contains(searchCategory));

            if (!string.IsNullOrEmpty(searchName))
                products = products.Where(p => p.ProductName.Contains(searchName));

            return View(await products.ToListAsync());
        }

        // GET: Farmers/Delete/5
        public async Task<IActionResult> Delete(int? id) //https://www.youtube.com/watch?v=_tiOquA9Yz4
        {
            if (id == null)
                return NotFound();

            string userIdString = HttpContext.Session.GetString("UserId");
            if (!int.TryParse(userIdString, out int farmerId))
                return RedirectToAction("Login", "Users");

            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            if (product.FarmerId != farmerId)
                return Unauthorized();

            return View(product);
        }

        // POST: Farmers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            string userIdString = HttpContext.Session.GetString("UserId");
            if (!int.TryParse(userIdString, out int farmerId))
                return RedirectToAction("Login", "Users");

            var product = await _context.Products.FindAsync(id);
            if (product != null && product.FarmerId == farmerId)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }


        // GET: Farmers/Details?email=someone@example.com
        public async Task<IActionResult> Details(string email)
        {
            if (string.IsNullOrEmpty(email))
                return NotFound();

            var farmer = await _context.Farmers.FirstOrDefaultAsync(f => f.Email == email);

            if (farmer == null)
                return NotFound();

            return View(farmer);
        }
    }
}


