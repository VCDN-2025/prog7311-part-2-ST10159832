﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers
{
    public class ProductsController : Controller    //https://www.youtube.com/watch?v=E7Voso411Vs
    {
        private readonly FarmManagementContext _context;

        public ProductsController(FarmManagementContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> DisplayInventory(string category, DateTime? startDate, DateTime? endDate) //https://www.youtube.com/watch?v=18Q4pGzL_U8
        {
            var products = _context.Products.AsQueryable();

            if (!string.IsNullOrEmpty(category))
                products = products.Where(p => p.Category.Contains(category));

            if (startDate.HasValue)
            {
                var start = DateOnly.FromDateTime(startDate.Value);
                products = products.Where(p => p.ProductDate >= start);
            }

            if (endDate.HasValue)
            {
                var end = DateOnly.FromDateTime(endDate.Value);
                products = products.Where(p => p.ProductDate <= end);
            }

            return View(await products.ToListAsync());
        }

        public async Task<IActionResult> Index()
        {
            var farmerId = int.Parse(HttpContext.Session.GetString("UserId"));
            var products = await _context.Products
                .Where(p => p.FarmerId == farmerId)
                .ToListAsync();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,ProductName,Category,ProductDate")] Product product) //https://www.youtube.com/watch?v=18Q4pGzL_U8
        {
            var LoggedUser = HttpContext.Session.GetString("LoggedInUser");

            var farmerId = _context.Farmers.Where(f => f.Email == LoggedUser).Select(f => f.FarmerId).FirstOrDefault();

            product.FarmerId = farmerId;
          

            if (ModelState.IsValid)
            {
                Console.WriteLine($"model is valid");
                _context.Add(product);
                await _context.SaveChangesAsync();

                return RedirectToAction("Index", "Farmers");
            }

            var errors = ModelState.Values.SelectMany(v => v.Errors);
            foreach (var error in errors)
            {
                Console.WriteLine($"ModelState error: {error.ErrorMessage}");
            }


            return View(product);
        }
    }
}
