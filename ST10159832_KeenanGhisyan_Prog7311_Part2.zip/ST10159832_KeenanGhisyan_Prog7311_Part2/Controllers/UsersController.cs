﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers    //https://www.youtube.com/watch?v=E7Voso411Vs
{
    public class UsersController : Controller
    {
        private readonly FarmManagementContext _context;

        public UsersController(FarmManagementContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index() //https://www.youtube.com/watch?v=18Q4pGzL_U8
        {
            var farmers = await _context.Users
                .Where(u => u.Role == "Farmer")
                .ToListAsync();

            return View(farmers);
        }

        public async Task<IActionResult> Delete(int? id) //https://www.youtube.com/watch?v=_tiOquA9Yz4
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(m => m.UserId == id);
            if (user == null) return NotFound();

            return View(user);
        }

        public IActionResult Create()
        {
            ViewData["Roles"] = new List<string> { "Farmer" };
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FullName,Email,Password,Role")] User user) //https://www.youtube.com/watch?v=18Q4pGzL_U8
        {
            bool existingUser = _context.Users.Any(u => u.Email == user.Email);

            if (ModelState.IsValid)
            {
                if (!existingUser)
                {
                    if (string.IsNullOrEmpty(user.Role))
                    {
                        user.Role = "Farmer";
                    }

                    _context.Users.Add(user);
                    await _context.SaveChangesAsync();

                    // Save email in session
                    HttpContext.Session.SetString("createdUserEmail", user.Email);

                    // Redirect to FarmerDetail after user creation
                    return RedirectToAction("FarmerDetail", "Users");
                }
                else
                {
                    ModelState.AddModelError("Email", "Email already exists.");
                }
            }

            ViewData["Roles"] = new List<string> { "Farmer" };
            return View(user);
        }

        // GET: Users/FarmerDetail
        public IActionResult FarmerDetail() //https://www.youtube.com/watch?v=18Q4pGzL_U8
        {
            var email = HttpContext.Session.GetString("createdUserEmail");
            if (string.IsNullOrEmpty(email))
                return RedirectToAction("Index");

            var farmer = new Farmer { Email = email };
            return View(farmer); // This will load FarmerDetail.cshtml
        }

        // POST: Users/FarmerDetail
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FarmerDetail([Bind("FirstName,LastName,Email,ContactNumber,Address")] Farmer farmer)
        {
            if (ModelState.IsValid)
            {
                _context.Farmers.Add(farmer);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(farmer);
        }
    }

}



