﻿using Microsoft.AspNetCore.Mvc;
using ST10159832_KeenanGhisyan_Prog7311_Part2.Models;

namespace ST10159832_KeenanGhisyan_Prog7311_Part2.Controllers
{     //https://www.youtube.com/watch?v=E7Voso411Vs 
    public class DashboardController : Controller
    {
        private readonly FarmManagementContext _context;

        public DashboardController(FarmManagementContext context)
        {
            _context = context;
        }

        // Employee Dashboard
        public IActionResult Employee()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (string.IsNullOrEmpty(role) || role != "Employee")
            {
                return RedirectToAction("Index", "Login");
            }

            return View("Employee");
        }

        // Farmer Dashboard
        public IActionResult Farmer()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (string.IsNullOrEmpty(role) || role != "Farmer")
            {
                return RedirectToAction("Index", "Login");
            }

            return View("Farmer");
        }
    }
}
